//
//  ViewController.swift
//  Tarea4
//
//  Created by Maggie Jimenez Herrera on 9/25/19.
//  Copyright © 2019 Maggie Jimenez Herrera. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

